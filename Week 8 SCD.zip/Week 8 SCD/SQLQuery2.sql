USE TempDatabase

CREATE TABLE Emp(
	ID int NULL,
	[First] varchar(50) NULL,
	[Last] varchar(50) NULL,
	Rate float NULL,
	Title varchar(50) NULL,
	Zip varchar(50) NULL
	)

select * from emp

CREATE TABLE DimEmp(
	DimEmpID INT identity (1,1) primary key,
	ID int NULL,
	[First] varchar(50) NULL,
	[Last] varchar(50) NULL,
	Rate float NULL,
	Title varchar(50) NULL,
	Zip varchar(50) NULL,
	[StartDate] datetime NULL,
	[EndDate] datetime,
	[UpdateDate] datetime,
	PriorZip varchar(50)

select * from DimEmp


-- 2. Zip code change to Betty Rubble

Update emp set Zip = 02903 where ID=4  

Select * from emp
Select * from dimemp

-- 3. John changes name

Update emp set First = 'Jon' where ID=1 

Select * from emp
Select * from dimemp

-- 4. Bob Gets a a raise

Update emp set Rate = 30.25 where ID=2 

Select * from emp
Select * from dimemp

-- 5. New Record

Insert into emp values(5, 'Chris', 'Roberts', 12, 'Marketing', 2901)

Select * from emp
Select * from dimemp

-- 6. Bob Jones Updates Name

Update emp set Last = 'Robert' where ID=2 

Select * from emp
Select * from dimemp

-- 7. Delete / Terminate a record

Delete From emp where id =3

Select * from emp
Select * from dimemp

